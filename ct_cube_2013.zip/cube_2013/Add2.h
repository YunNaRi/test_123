#pragma once
class Add2
{
public:
	Add2(void);
	~Add2(void);
};

