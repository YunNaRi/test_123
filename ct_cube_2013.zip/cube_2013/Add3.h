#pragma once
class Add3
{
public:
	Add3(void);
	~Add3(void);
};

