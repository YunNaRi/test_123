#include "Add7.h"


Add7::Add7(void)
{
}


Add7::~Add7(void)
{
}
