#include "Add6.h"


Add6::Add6(void)
{
}


Add6::~Add6(void)
{
}
