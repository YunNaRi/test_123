#pragma once
class Add4
{
public:
	Add4(void);
	~Add4(void);
};

