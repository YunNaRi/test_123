#pragma once
class add
{
public:
	add(void);
	~add(void);
};

