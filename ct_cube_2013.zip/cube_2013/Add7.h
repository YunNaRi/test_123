#pragma once
class Add7
{
public:
	Add7(void);
	~Add7(void);
};

