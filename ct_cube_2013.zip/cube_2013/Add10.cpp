#include "Add10.h"


Add10::Add10(void)
{
}


Add10::~Add10(void)
{
}
