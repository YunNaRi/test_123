#pragma once
class Add10
{
public:
	Add10(void);
	~Add10(void);
};

