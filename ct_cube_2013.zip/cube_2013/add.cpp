#include "add.h"


add::add()
{
	int a;
}


