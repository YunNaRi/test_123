#pragma once
class Add11
{
public:
	Add11(void);
	~Add11(void);
};

