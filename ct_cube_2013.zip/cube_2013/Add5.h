#pragma once
class Add5
{
public:
	Add5(void);
	~Add5(void);
};

