#pragma once
class Add6
{
public:
	Add6(void);
	~Add6(void);
};

