#include "Add8.h"


Add8::Add8(void)
{
}


Add8::~Add8(void)
{
}
