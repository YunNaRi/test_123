#include "Add5.h"


Add5::Add5(void)
{
}


Add5::~Add5(void)
{
}
