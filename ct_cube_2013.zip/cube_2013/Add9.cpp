#include "Add9.h"


Add9::Add9(void)
{
}


Add9::~Add9(void)
{
}
