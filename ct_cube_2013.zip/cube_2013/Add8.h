#pragma once
class Add8
{
public:
	Add8(void);
	~Add8(void);
};

