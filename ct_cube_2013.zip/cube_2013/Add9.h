#pragma once
class Add9
{
public:
	Add9(void);
	~Add9(void);
};

