#include "Add3.h"


Add3::Add3(void)
{
}


Add3::~Add3(void)
{
}
