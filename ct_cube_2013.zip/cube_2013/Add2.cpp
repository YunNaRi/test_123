#include "Add2.h"


Add2::Add2(void)
{
}


Add2::~Add2(void)
{
}
