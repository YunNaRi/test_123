#include "Add4.h"


Add4::Add4(void)
{
}


Add4::~Add4(void)
{
}
